#!/bin/bash

mpirun -np $2 ./mandelbrot_mpi $1 $2